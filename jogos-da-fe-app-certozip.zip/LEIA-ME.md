# Como gerar o APK do Jogos da Fé (grátis, sem hospedagem)

O jogo fica DENTRO do app: funciona sem internet e não depende de nenhum site.

1. Crie uma conta grátis em https://github.com
2. Clique em **New repository**, dê o nome `jogos-da-fe` e crie.
3. Descompacte este zip no computador. Clique em **uploading an existing file** e arraste TODO o conteúdo (incluindo a pasta `.github`).
   - Se a pasta `.github` não subir: **Add file > Create new file**, digite o nome `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo de mesmo nome.
4. Clique em **Commit changes**.
5. Vá na aba **Actions** > **Gerar APK**. Espere uns 5 a 10 minutos (bolinha verde).
6. Abra a execução, desça até **Artifacts**, baixe **Jogos-da-Fe-APK** (vem em zip), descompacte e instale o `app-debug.apk` no celular.
